<?php
/* Template Name: Contact Us Page Template */ 

 
get_header(); ?>

<div class="main-wrapper">
    <section class="section-wrapper contact-page">
        <div class="container">
            <div class="row">
                <div class="col-12 col-12 col-lg-12">
                    <div class="section-title">
                        <h1>We're ready to help.</h1>
                    </div>
                </div>
                <div class="col-12 col-md-6">
                    <div class="cform contact-form">
                        <h2>Get in Touch</h2>
                        <?php echo do_shortcode( '[contact-form-7 id="a33b622" title="Contact Form for all pages"]' ); ?> 
                    </div>
                </div>
                <div class="col-12 col-md-6">
                    <div class="contact-image">
                        <img src="https://valainfotech.com/projects/minnehahafallslandscape/wp-content/themes/minnehaha-fall/assets/images/contact.jpeg" alt="Image">
                    </div>
                </div>
            </div>
        </div>
    </section>
 
    <!-- Service Partners -->
    <?php echo do_shortcode( '[minnehahafall_service_partners]' ); ?> 
    
    <!-- SIte CTA Section -->
    <?php echo do_shortcode( '[minnehahafall_CTA_section]' ); ?> 
 
</div>

<?php
get_footer();