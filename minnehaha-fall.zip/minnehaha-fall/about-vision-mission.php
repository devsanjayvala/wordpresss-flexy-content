<?php
/* Template Name: About - Vision Mission Page Template */ 

 
get_header();

// Get the directory URI of the child theme
$child_theme_uri = get_stylesheet_directory_uri();

$page_id = get_the_ID();
$page_image = get_field( "page_image", $page_id);
$vision_title = get_field( "vision_title", $page_id);
$vision_description = get_field( "vision_description", $page_id);
$values_title = get_field( "values_title", $page_id);
$values_description = get_field( "values_description", $page_id);
$services_title = get_field( "services_title", $page_id);
 
?>
<div class="main-wrapper">
 
    <section class="about-banner">
        <img src="<?php echo $page_image; ?>" alt="Image">
    </section>
    <section class="section-wrapper about-content">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="content">
                        <?php
                        if ($vision_title != '' && $vision_description !='') {
                            echo '<h1>'.$vision_title.'</h1>';
                            echo $vision_description;
                        }
                        
                        if ($values_title != '' && $values_description !='') {
                            echo '<h2>'.$values_title.'</h2>';
                            echo $values_description;
                        }
                        ?>
                        <div class="box-year">
                            <div class="box-year-wrapper">
                                <?php
                                if( have_rows('history_list') ):
                                while( have_rows('history_list') ): the_row();
                                    $year = get_sub_field('year');
                                    $description = get_sub_field('description');                                    
                                    if ($description !='' && $name != '') {
                                        ?>
                                        <div class="year-item">
                                            <h2><?php echo $year; ?></h2>
                                            <p><?php echo $description; ?></p>
                                        </div>
                                        <?php
                                    } 
                                endwhile;
                                endif;
                                ?> 
                            </div>
                        </div>
                        <?php
                        if ($services_title != '') {
                            echo '<h2>'.$services_title.'</h2>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Service Partners -->
    <?php echo do_shortcode( '[minnehahafall_service_partners]' ); ?> 

    <section class="section-wrapper contact-us">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="cform contact-form">
                        <h2>Get in Touch</h2>
                        <?php echo do_shortcode( '[contact-form-7 id="a33b622" title="Contact Form for all pages"]' ); ?> 
                    </div>
                </div>
                <div class="col-12 col-md-6">                
                <?php echo do_shortcode( '[minnehahafall_client_reviews]' ); ?> 
                </div>
            </div>
        </div>
    </section>

    <!-- SIte CTA Section -->
    <?php echo do_shortcode( '[minnehahafall_CTA_section]' ); ?>

</div>

<?php
get_footer();