<?php
/**
 * Functions and definitions
 *
 *  
 *
 * @package WordPress
 * @subpackage Minnehahafall
 * @since Minnehahafall 1.0
 */

// This theme requires WordPress 5.3 or later.
// if ( version_compare( $GLOBALS['wp_version'], '5.3', '<' ) ) {
// 	require get_template_directory() . '/inc/back-compat.php';
// }

if ( ! function_exists( 'twenty_twenty_one_setup' ) ) {
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 *
	 * @since Twenty Twenty-One 1.0
	 *
	 * @return void
	 */
	function twenty_twenty_one_setup() {

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * This theme does not use a hard-coded <title> tag in the document head,
		 * WordPress will provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/**
		 * Add post-formats support.
		 */
		add_theme_support(
			'post-formats',
			array(
				'link',
				'aside',
				'gallery',
				'image',
				'quote',
				'status',
				'video',
				'audio',
				'chat',
			)
		);

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );
		set_post_thumbnail_size( 1568, 9999 );

		register_nav_menus(
			array(
				'primary' => esc_html__( 'Primary menu', 'twentytwentyone' ),
				'footer'  => esc_html__( 'Secondary menu', 'twentytwentyone' ),
			)
		);

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support(
			'html5',
			array(
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
				'navigation-widgets',
			)
		);

		/*
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		$logo_width  = 300;
		$logo_height = 100;

		add_theme_support(
			'custom-logo',
			array(
				'height'               => $logo_height,
				'width'                => $logo_width,
				'flex-width'           => true,
				'flex-height'          => true,
				'unlink-homepage-logo' => true,
			)
		);

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		// Add support for Block Styles.
		add_theme_support( 'wp-block-styles' );

		// Add support for full and wide align images.
		add_theme_support( 'align-wide' );

		// Add support for editor styles.
		add_theme_support( 'editor-styles' );
		$background_color = get_theme_mod( 'background_color', 'D1E4DD' );
		if ( 127 > Twenty_Twenty_One_Custom_Colors::get_relative_luminance_from_hex( $background_color ) ) {
			add_theme_support( 'dark-editor-style' );
		}

		$editor_stylesheet_path = './assets/css/style-editor.css';

		// Note, the is_IE global variable is defined by WordPress and is used
		// to detect if the current browser is internet explorer.
		global $is_IE;
		if ( $is_IE ) {
			$editor_stylesheet_path = './assets/css/ie-editor.css';
		}

		// Enqueue editor styles.
		add_editor_style( $editor_stylesheet_path );

		// Add custom editor font sizes.
		add_theme_support(
			'editor-font-sizes',
			array(
				array(
					'name'      => esc_html__( 'Extra small', 'twentytwentyone' ),
					'shortName' => esc_html_x( 'XS', 'Font size', 'twentytwentyone' ),
					'size'      => 16,
					'slug'      => 'extra-small',
				),
				array(
					'name'      => esc_html__( 'Small', 'twentytwentyone' ),
					'shortName' => esc_html_x( 'S', 'Font size', 'twentytwentyone' ),
					'size'      => 18,
					'slug'      => 'small',
				),
				array(
					'name'      => esc_html__( 'Normal', 'twentytwentyone' ),
					'shortName' => esc_html_x( 'M', 'Font size', 'twentytwentyone' ),
					'size'      => 20,
					'slug'      => 'normal',
				),
				array(
					'name'      => esc_html__( 'Large', 'twentytwentyone' ),
					'shortName' => esc_html_x( 'L', 'Font size', 'twentytwentyone' ),
					'size'      => 24,
					'slug'      => 'large',
				),
				array(
					'name'      => esc_html__( 'Extra large', 'twentytwentyone' ),
					'shortName' => esc_html_x( 'XL', 'Font size', 'twentytwentyone' ),
					'size'      => 40,
					'slug'      => 'extra-large',
				),
				array(
					'name'      => esc_html__( 'Huge', 'twentytwentyone' ),
					'shortName' => esc_html_x( 'XXL', 'Font size', 'twentytwentyone' ),
					'size'      => 96,
					'slug'      => 'huge',
				),
				array(
					'name'      => esc_html__( 'Gigantic', 'twentytwentyone' ),
					'shortName' => esc_html_x( 'XXXL', 'Font size', 'twentytwentyone' ),
					'size'      => 144,
					'slug'      => 'gigantic',
				),
			)
		);

		// Custom background color.
		add_theme_support(
			'custom-background',
			array(
				'default-color' => 'd1e4dd',
			)
		);

		// Editor color palette.
		$black     = '#000000';
		$dark_gray = '#28303D';
		$gray      = '#39414D';
		$green     = '#D1E4DD';
		$blue      = '#D1DFE4';
		$purple    = '#D1D1E4';
		$red       = '#E4D1D1';
		$orange    = '#E4DAD1';
		$yellow    = '#EEEADD';
		$white     = '#FFFFFF';

		add_theme_support(
			'editor-color-palette',
			array(
				array(
					'name'  => esc_html__( 'Black', 'twentytwentyone' ),
					'slug'  => 'black',
					'color' => $black,
				),
				array(
					'name'  => esc_html__( 'Dark gray', 'twentytwentyone' ),
					'slug'  => 'dark-gray',
					'color' => $dark_gray,
				),
				array(
					'name'  => esc_html__( 'Gray', 'twentytwentyone' ),
					'slug'  => 'gray',
					'color' => $gray,
				),
				array(
					'name'  => esc_html__( 'Green', 'twentytwentyone' ),
					'slug'  => 'green',
					'color' => $green,
				),
				array(
					'name'  => esc_html__( 'Blue', 'twentytwentyone' ),
					'slug'  => 'blue',
					'color' => $blue,
				),
				array(
					'name'  => esc_html__( 'Purple', 'twentytwentyone' ),
					'slug'  => 'purple',
					'color' => $purple,
				),
				array(
					'name'  => esc_html__( 'Red', 'twentytwentyone' ),
					'slug'  => 'red',
					'color' => $red,
				),
				array(
					'name'  => esc_html__( 'Orange', 'twentytwentyone' ),
					'slug'  => 'orange',
					'color' => $orange,
				),
				array(
					'name'  => esc_html__( 'Yellow', 'twentytwentyone' ),
					'slug'  => 'yellow',
					'color' => $yellow,
				),
				array(
					'name'  => esc_html__( 'White', 'twentytwentyone' ),
					'slug'  => 'white',
					'color' => $white,
				),
			)
		);

		add_theme_support(
			'editor-gradient-presets',
			array(
				array(
					'name'     => esc_html__( 'Purple to yellow', 'twentytwentyone' ),
					'gradient' => 'linear-gradient(160deg, ' . $purple . ' 0%, ' . $yellow . ' 100%)',
					'slug'     => 'purple-to-yellow',
				),
				array(
					'name'     => esc_html__( 'Yellow to purple', 'twentytwentyone' ),
					'gradient' => 'linear-gradient(160deg, ' . $yellow . ' 0%, ' . $purple . ' 100%)',
					'slug'     => 'yellow-to-purple',
				),
				array(
					'name'     => esc_html__( 'Green to yellow', 'twentytwentyone' ),
					'gradient' => 'linear-gradient(160deg, ' . $green . ' 0%, ' . $yellow . ' 100%)',
					'slug'     => 'green-to-yellow',
				),
				array(
					'name'     => esc_html__( 'Yellow to green', 'twentytwentyone' ),
					'gradient' => 'linear-gradient(160deg, ' . $yellow . ' 0%, ' . $green . ' 100%)',
					'slug'     => 'yellow-to-green',
				),
				array(
					'name'     => esc_html__( 'Red to yellow', 'twentytwentyone' ),
					'gradient' => 'linear-gradient(160deg, ' . $red . ' 0%, ' . $yellow . ' 100%)',
					'slug'     => 'red-to-yellow',
				),
				array(
					'name'     => esc_html__( 'Yellow to red', 'twentytwentyone' ),
					'gradient' => 'linear-gradient(160deg, ' . $yellow . ' 0%, ' . $red . ' 100%)',
					'slug'     => 'yellow-to-red',
				),
				array(
					'name'     => esc_html__( 'Purple to red', 'twentytwentyone' ),
					'gradient' => 'linear-gradient(160deg, ' . $purple . ' 0%, ' . $red . ' 100%)',
					'slug'     => 'purple-to-red',
				),
				array(
					'name'     => esc_html__( 'Red to purple', 'twentytwentyone' ),
					'gradient' => 'linear-gradient(160deg, ' . $red . ' 0%, ' . $purple . ' 100%)',
					'slug'     => 'red-to-purple',
				),
			)
		);

		/*
		* Adds starter content to highlight the theme on fresh sites.
		* This is done conditionally to avoid loading the starter content on every
		* page load, as it is a one-off operation only needed once in the customizer.
		*/
		if ( is_customize_preview() ) {
			require get_template_directory() . '/inc/starter-content.php';
			add_theme_support( 'starter-content', twenty_twenty_one_get_starter_content() );
		}

		// Add support for responsive embedded content.
		add_theme_support( 'responsive-embeds' );

		// Add support for custom line height controls.
		add_theme_support( 'custom-line-height' );

		// Add support for link color control.
		add_theme_support( 'link-color' );

		// Add support for experimental cover block spacing.
		add_theme_support( 'custom-spacing' );

		// Add support for custom units.
		// This was removed in WordPress 5.6 but is still required to properly support WP 5.5.
		add_theme_support( 'custom-units' );

		// Remove feed icon link from legacy RSS widget.
		add_filter( 'rss_widget_feed_link', '__return_empty_string' );
	}
}
add_action( 'after_setup_theme', 'twenty_twenty_one_setup' );

/**
 * Registers widget area.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 *
 * @return void
 */
function twenty_twenty_one_widgets_init() {

	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer', 'twentytwentyone' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here to appear in your footer.', 'twentytwentyone' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Contact Info', 'twentytwentyone' ),
			'id'            => 'sidebar-2',
			'description'   => esc_html__( 'Add widgets here to appear in your footer.', 'twentytwentyone' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'twenty_twenty_one_widgets_init' );

/**
 * Sets the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @global int $content_width Content width.
 *
 * @return void
 */
function twenty_twenty_one_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'twenty_twenty_one_content_width', 750 );
}
add_action( 'after_setup_theme', 'twenty_twenty_one_content_width', 0 );

/**
 * Enqueues scripts and styles.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @global bool       $is_IE
 * @global WP_Scripts $wp_scripts
 *
 * @return void
 */
function twenty_twenty_one_scripts() {
	// Note, the is_IE global variable is defined by WordPress and is used
	// to detect if the current browser is internet explorer.
	global $is_IE, $wp_scripts;
	if ( $is_IE ) {
		// If IE 11 or below, use a flattened stylesheet with static values replacing CSS Variables.
		wp_enqueue_style( 'twenty-twenty-one-style', get_template_directory_uri() . '/assets/css/ie.css', array(), wp_get_theme()->get( 'Version' ) );
	} else {
		// If not IE, use the standard stylesheet.
		wp_enqueue_style( 'twenty-twenty-one-style', get_template_directory_uri() . '/style.css', array(), wp_get_theme()->get( 'Version' ) );
	}

	// RTL styles.
	wp_style_add_data( 'twenty-twenty-one-style', 'rtl', 'replace' );

	// Print styles.
	wp_enqueue_style( 'twenty-twenty-one-print-style', get_template_directory_uri() . '/assets/css/print.css', array(), wp_get_theme()->get( 'Version' ), 'print' );

	// Threaded comment reply styles.
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	// Register the IE11 polyfill file.
	wp_register_script(
		'twenty-twenty-one-ie11-polyfills-asset',
		get_template_directory_uri() . '/assets/js/polyfills.js',
		array(),
		wp_get_theme()->get( 'Version' ),
		array( 'in_footer' => true )
	);

	// Register the IE11 polyfill loader.
	wp_register_script(
		'twenty-twenty-one-ie11-polyfills',
		null,
		array(),
		wp_get_theme()->get( 'Version' ),
		array( 'in_footer' => true )
	);
	wp_add_inline_script(
		'twenty-twenty-one-ie11-polyfills',
		wp_get_script_polyfill(
			$wp_scripts,
			array(
				'Element.prototype.matches && Element.prototype.closest && window.NodeList && NodeList.prototype.forEach' => 'twenty-twenty-one-ie11-polyfills-asset',
			)
		)
	);

	// Main navigation scripts.
	if ( has_nav_menu( 'primary' ) ) {
		wp_enqueue_script(
			'twenty-twenty-one-primary-navigation-script',
			get_template_directory_uri() . '/assets/js/primary-navigation.js',
			array( 'twenty-twenty-one-ie11-polyfills' ),
			wp_get_theme()->get( 'Version' ),
			array(
				'in_footer' => false, // Because involves header.
				'strategy'  => 'defer',
			)
		);
	}

	// Responsive embeds script.
	wp_enqueue_script(
		'twenty-twenty-one-responsive-embeds-script',
		get_template_directory_uri() . '/assets/js/responsive-embeds.js',
		array( 'twenty-twenty-one-ie11-polyfills' ),
		wp_get_theme()->get( 'Version' ),
		array( 'in_footer' => true )
	);
}
add_action( 'wp_enqueue_scripts', 'twenty_twenty_one_scripts' );

/**
 * Enqueues block editor script.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @return void
 */
function twentytwentyone_block_editor_script() {

	wp_enqueue_script( 'twentytwentyone-editor', get_theme_file_uri( '/assets/js/editor.js' ), array( 'wp-blocks', 'wp-dom' ), wp_get_theme()->get( 'Version' ), array( 'in_footer' => true ) );
}

add_action( 'enqueue_block_editor_assets', 'twentytwentyone_block_editor_script' );

/**
 * Fixes skip link focus in IE11.
 *
 * This does not enqueue the script because it is tiny and because it is only for IE11,
 * thus it does not warrant having an entire dedicated blocking script being loaded.
 *
 * @since Twenty Twenty-One 1.0
 * @deprecated Twenty Twenty-One 1.9 Removed from wp_print_footer_scripts action.
 *
 * @link https://git.io/vWdr2
 */
function twenty_twenty_one_skip_link_focus_fix() {

	// If SCRIPT_DEBUG is defined and true, print the unminified file.
	if ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) {
		echo '<script>';
		include get_template_directory() . '/assets/js/skip-link-focus-fix.js';
		echo '</script>';
	} else {
		// The following is minified via `npx terser --compress --mangle -- assets/js/skip-link-focus-fix.js`.
		?>
		<script>
		/(trident|msie)/i.test(navigator.userAgent)&&document.getElementById&&window.addEventListener&&window.addEventListener("hashchange",(function(){var t,e=location.hash.substring(1);/^[A-z0-9_-]+$/.test(e)&&(t=document.getElementById(e))&&(/^(?:a|select|input|button|textarea)$/i.test(t.tagName)||(t.tabIndex=-1),t.focus())}),!1);
		</script>
		<?php
	}
}

/**
 * Enqueues non-latin language styles.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @return void
 */
function twenty_twenty_one_non_latin_languages() {
	$custom_css = twenty_twenty_one_get_non_latin_css( 'front-end' );

	if ( $custom_css ) {
		wp_add_inline_style( 'twenty-twenty-one-style', $custom_css );
	}
}
add_action( 'wp_enqueue_scripts', 'twenty_twenty_one_non_latin_languages' );

// SVG Icons class.
require get_template_directory() . '/classes/class-twenty-twenty-one-svg-icons.php';

// Custom color classes.
require get_template_directory() . '/classes/class-twenty-twenty-one-custom-colors.php';
new Twenty_Twenty_One_Custom_Colors();

// Enhance the theme by hooking into WordPress.
require get_template_directory() . '/inc/template-functions.php';

// Menu functions and filters.
require get_template_directory() . '/inc/menu-functions.php';

// Custom template tags for the theme.
require get_template_directory() . '/inc/template-tags.php';

// Customizer additions.
require get_template_directory() . '/classes/class-twenty-twenty-one-customize.php';
new Twenty_Twenty_One_Customize();

// Block Patterns.
require get_template_directory() . '/inc/block-patterns.php';

// Block Styles.
require get_template_directory() . '/inc/block-styles.php';

// Dark Mode.
require_once get_template_directory() . '/classes/class-twenty-twenty-one-dark-mode.php';
new Twenty_Twenty_One_Dark_Mode();

/**
 * Enqueues scripts for the customizer preview.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @return void
 */
function twentytwentyone_customize_preview_init() {
	wp_enqueue_script(
		'twentytwentyone-customize-helpers',
		get_theme_file_uri( '/assets/js/customize-helpers.js' ),
		array(),
		wp_get_theme()->get( 'Version' ),
		array( 'in_footer' => true )
	);

	wp_enqueue_script(
		'twentytwentyone-customize-preview',
		get_theme_file_uri( '/assets/js/customize-preview.js' ),
		array( 'customize-preview', 'customize-selective-refresh', 'jquery', 'twentytwentyone-customize-helpers' ),
		wp_get_theme()->get( 'Version' ),
		array( 'in_footer' => true )
	);
}
add_action( 'customize_preview_init', 'twentytwentyone_customize_preview_init' );

/**
 * Enqueues scripts for the customizer.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @return void
 */
function twentytwentyone_customize_controls_enqueue_scripts() {

	wp_enqueue_script(
		'twentytwentyone-customize-helpers',
		get_theme_file_uri( '/assets/js/customize-helpers.js' ),
		array(),
		wp_get_theme()->get( 'Version' ),
		array( 'in_footer' => true )
	);
}
add_action( 'customize_controls_enqueue_scripts', 'twentytwentyone_customize_controls_enqueue_scripts' );

/**
 * Calculates classes for the main <html> element.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @return void
 */
function twentytwentyone_the_html_classes() {
	/**
	 * Filters the classes for the main <html> element.
	 *
	 * @since Twenty Twenty-One 1.0
	 *
	 * @param string The list of classes. Default empty string.
	 */
	$classes = apply_filters( 'twentytwentyone_html_classes', '' );
	if ( ! $classes ) {
		return;
	}
	echo 'class="' . esc_attr( $classes ) . '"';
}

/**
 * Adds "is-IE" class to body if the user is on Internet Explorer.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @return void
 */
function twentytwentyone_add_ie_class() {
	?>
	<script>
	if ( -1 !== navigator.userAgent.indexOf( 'MSIE' ) || -1 !== navigator.appVersion.indexOf( 'Trident/' ) ) {
		document.body.classList.add( 'is-IE' );
	}
	</script>
	<?php
}
add_action( 'wp_footer', 'twentytwentyone_add_ie_class' );

if ( ! function_exists( 'wp_get_list_item_separator' ) ) :
	/**
	 * Retrieves the list item separator based on the locale.
	 *
	 * Added for backward compatibility to support pre-6.0.0 WordPress versions.
	 *
	 * @since 6.0.0
	 */
	function wp_get_list_item_separator() {
		/* translators: Used between list items, there is a space after the comma. */
		return __( ', ', 'twentytwentyone' );
	}
endif;




// Custom Theme Options

/**
 * Customizer Settings
 */
add_action( 'customize_register', 'register_customize_sections' );

function register_customize_sections( $wp_customize ) {

    $wp_customize->add_section( 'header_section', array(

       'title'=> __( 'Header', 'TextDomain' ),
       'priority' => 21
    ) );

    // $wp_customize->add_setting( 'site_main_logo' );
 
	// $wp_customize->add_control(
	// 	new WP_Customize_Image_Control(
	// 		$wp_customize,
	// 		'site_main_logo',
	// 		array(
	// 			'label' => __('Header Main Logo','TextDomain'),
	// 			'section' => 'header_section',
	// 			'settings' => 'site_main_logo',
    //             // 'priority'   => 15
	// 		)
	// 	)
	// );

    // $wp_customize->add_setting( 'site_main_sticky_logo' );
 
	// $wp_customize->add_control(
	// 	new WP_Customize_Image_Control(
	// 		$wp_customize,
	// 		'site_main_sticky_logo',
	// 		array(
	// 			'label' => __('Header Sticky Logo','TextDomain'),
	// 			'section' => 'header_section',
	// 			'settings' => 'site_main_sticky_logo',
    //             // 'priority'   => 15
	// 		)
	// 	)
	// );

    // $wp_customize->add_setting( 'mobile_header_logo' );
 
	// $wp_customize->add_control(
	// 	new WP_Customize_Image_Control(
	// 		$wp_customize,
	// 		'mobile_header_logo',
	// 		array(
	// 			'label' => __('Mobile Header Logo','TextDomain'),
	// 			'section' => 'header_section',
	// 			'settings' => 'mobile_header_logo',
    //             // 'priority'   => 15
	// 		)
	// 	)
	// );

    // $wp_customize->add_setting( 'mobile_header_sticky_logo' );
 
	// $wp_customize->add_control(
	// 	new WP_Customize_Image_Control(
	// 		$wp_customize,
	// 		'mobile_header_sticky_logo',
	// 		array(
	// 			'label' => __('Mobile Header Sticky Logo','TextDomain'),
	// 			'section' => 'header_section',
	// 			'settings' => 'mobile_header_sticky_logo',
    //             // 'priority'   => 15
	// 		)
	// 	)
	// );

    $wp_customize->add_setting( 'cta_title' );
    $wp_customize->add_control( 'cta_title', array(
        'id'=> 'cta_title',
        'label' => __( 'CTA Title:', 'TextDomain' ),
        'section' => 'header_section'
    ) );

    $wp_customize->add_setting( 'cta_link' );
    $wp_customize->add_control( 'cta_link', array(
        'id'=> 'cta_link',
        'label' => __( 'CTA Link:', 'TextDomain' ),
        'section' => 'header_section'
    ) );
 
    $wp_customize->add_setting( 'cta_phone' );
    $wp_customize->add_control( 'cta_phone', array(
        'id'=> 'cta_phone',
        'label' => __( 'CTA Phone:', 'TextDomain' ),
        'section' => 'header_section'
    ) );

    $wp_customize->add_setting( 'header_top_tagline' );
    $wp_customize->add_control( 'header_top_tagline', array(
        'id'=> 'header_top_tagline',
        'label' => __( 'Header Top Tagline:', 'TextDomain' ),
        'section' => 'header_section'
    ) );
 

    $wp_customize->add_section( 'footer_setting', array(

       'title'=> __( 'Footer', 'TextDomain' ),
       'priority' => 22
    ) );

	// $wp_customize->add_setting( 'footer_logo' );
 
	// $wp_customize->add_control(
	// 	new WP_Customize_Image_Control(
	// 		$wp_customize,
	// 		'footer_logo',
	// 		array(
	// 			'label' => __('Footer Logo','TextDomain'),
	// 			'section' => 'footer_setting',
	// 			'settings' => 'footer_logo',
    //             // 'priority'   => 15
	// 		)
	// 	)
	// );

	$wp_customize->add_setting( 'footer_copyright' );
    $wp_customize->add_control( 'footer_copyright', array(
        'id'=> 'footer_copyright',
        'label' => __( 'Footer Copyright:', 'TextDomain' ),
        'section' => 'footer_setting'
    ) );

    // $wp_customize->add_setting( 'footer_cta_section_title' );
    // $wp_customize->add_control( 'footer_cta_section_title', array(
    //     'id'=> 'footer_cta_section_title',
    //     'label' => __( 'CTA Title:', 'TextDomain' ),
    //     'section' => 'footer_setting'
    // ) );

    // $wp_customize->add_setting( 'footer_cta_section_description' );
    // $wp_customize->add_control( 'footer_cta_section_description', array(
    //     'id'=> 'footer_cta_section_description',
    //     'label' => __( 'CTA Description:', 'TextDomain' ),
    //     'section' => 'footer_setting',
    //     'type' => 'textarea'
    // ) );

    // $wp_customize->add_setting( 'footer_cta_btn_title' );
    // $wp_customize->add_control( 'footer_cta_btn_title', array(
    //     'id'=> 'footer_cta_btn_title',
    //     'label' => __( 'CTA Button Title:', 'TextDomain' ),
    //     'section' => 'footer_setting'
    // ) );

    // $wp_customize->add_setting( 'footer_cta_btn_link' );
    // $wp_customize->add_control( 'footer_cta_btn_link', array(
    //     'id'=> 'footer_cta_btn_link',
    //     'label' => __( 'CTA Button Link:', 'TextDomain' ),
    //     'section' => 'footer_setting'
    // ) );

    $wp_customize->add_section( 'social_links_setting', array(

       'title'=> __( 'Social Links', 'TextDomain' ),
       'priority' => 23
    ) );

    $wp_customize->add_setting( 'social_link_facebook' );
    $wp_customize->add_control( 'social_link_facebook', array(
        'id'=> 'social_link_facebook',
        'label' => __( 'Facebook Link:', 'TextDomain' ),
        'section' => 'social_links_setting',
		'input_attrs' => array(
			'placeholder' => __( 'Facebook link' ),
		),
    ) );

    $wp_customize->add_setting( 'social_link_linkedin' );
    $wp_customize->add_control( 'social_link_linkedin', array(
        'id'=> 'social_link_linkedin',
        'label' => __( 'LinkedIn Link:', 'TextDomain' ),
        'section' => 'social_links_setting',
		'input_attrs' => array(
			'placeholder' => __( 'LinkedIn link' ),
		),
    ) );

    $wp_customize->add_setting( 'social_link_instagram' );
    $wp_customize->add_control( 'social_link_instagram', array(
        'id'=> 'social_link_instagram',
        'label' => __( 'Instagram Link:', 'TextDomain' ),
        'section' => 'social_links_setting',
		'input_attrs' => array(
			'placeholder' => __( 'Instagram link' ),
		),
    ) );

	$wp_customize->add_section( 'cta_section', array(

		'title'=> __( 'CTA Section', 'TextDomain' ),
		'priority' => 24
	 ) );
 
	 $wp_customize->add_setting( 'cta_section_title' );
	 $wp_customize->add_control( 'cta_section_title', array(
		 'id'=> 'cta_section_title',
		 'label' => __( 'CTA Title:', 'TextDomain' ),
		 'section' => 'cta_section',
		 'input_attrs' => array(
			 'placeholder' => __( 'Lets talk!' ),
		 ),
	 ) );
 
	 $wp_customize->add_setting( 'cta_section_phone' );
	 $wp_customize->add_control( 'cta_section_phone', array(
		 'id'=> 'cta_section_phone',
		 'label' => __( 'CTA Phone:', 'TextDomain' ),
		 'section' => 'cta_section',
		 'input_attrs' => array(
			 'placeholder' => __( '612-724-5454' ),
		 ),
	 ) );
	 $wp_customize->add_setting( 'cta_section_button_link' );
	 $wp_customize->add_control( 'cta_section_button_link', array(
		 'id'=> 'cta_section_button_link',
		 'label' => __( 'CTA Button Link:', 'TextDomain' ),
		 'section' => 'cta_section',
		 'input_attrs' => array(
			 'placeholder' => __( '#' ),
		 ),
	 ) );
  
}



/**
 * Footer BLock Registered
 */
// Footer Menu 1
function footer_menu_1() {
    register_nav_menu('footer-menu-1', __('Footer Menu 1'));
}
add_action('after_setup_theme', 'footer_menu_1');




// Footer Menu 2
function footer_menu_2() {
    register_nav_menu('footer-menu-2', __('Footer Menu 2'));
}
add_action('after_setup_theme', 'footer_menu_2');


// Footer Menu 3
function footer_menu_3() {
    register_nav_menu('footer-menu-3', __('Footer Menu 3'));
}
add_action('after_setup_theme', 'footer_menu_3');


// Footer Menu 4
function footer_menu_4() {
    register_nav_menu('footer-menu-4', __('Footer Menu 4'));
}
add_action('after_setup_theme', 'footer_menu_4');



add_filter( 'auto_update_theme', '__return_false' );



add_action( 'init', 'digitxl_services_cpt' );
// The custom function to register a custom article post type
function digitxl_services_cpt() {
	
    $labels = array(
        'name'               => __( 'Service Partner' ),
        'singular_name'      => __( 'Service Partner' ),
        'add_new'            => __( 'Add New Service Partner' ),
        'add_new_item'       => __( 'Add New Service Partner' ),
        'edit_item'          => __( 'Edit Service Partner' ),
        'new_item'           => __( 'New Service Partner' ),
        'all_items'          => __( 'All Service Partners' ),
        'view_item'          => __( 'View Service Partner' ),
        'search_items'       => __( 'Search Service Partner' ),
        'featured_image'     => 'Poster',
        'set_featured_image' => 'Add Poster'
    );
	
    $args = array(
        'labels'            => $labels,
        'description'       => 'Holds our Service Partners post specific data',
        'public'            => true,
        'menu_position'     => 5,
        'supports'          => array( 'title', 'custom-fields' ),
        'has_archive'       => true,
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => true,
        'query_var'         => true,
    );
	
    register_post_type('service-partner', $args);
}


/**
 * Service Partners shortcode: [minnehahafall_service_partners]
 */
function minnehahafall_service_partners() {
	ob_start();
    ?>  
	<section class="section-wrapper feature">
        <div class="container">
            <div class="row">
				<?php
				$partners = get_posts( array( 'post_type' => 'service-partner', 'posts_per_page' => -1, 'orderby'=> 'date', 'order' => 'ASC' ) );
				if( $partners ):
				foreach( $partners as $post ) :  
					$partner_logo = get_field( "partner_logo", $post->ID);
					$description = get_field( "description", $post->ID);
					$link = get_field( "link", $post->ID); 
					if ($partner_logo != '') { 
						?>
						<div class="col-12 col-md-4 col-lg-4">
							<div class="feature-item">
								<div class="feature-image">
									<a href="<?php echo $link['url']; ?>" target="<?php if ($link['target'] != '') { echo ' _blank'; } ?>">
										<img src="<?php echo $partner_logo; ?>" alt="Image">
									</a>
								</div>
								<div class="feature-content">
									<p><?php echo $description; ?></p>
								</div>
							</div>
						</div>
						<?php
					}
					endforeach; 
				wp_reset_postdata(); 
				endif;
				?> 
            </div>
        </div>
    </section>
    <?php
	return ob_get_clean();
}
add_shortcode( 'minnehahafall_service_partners', 'minnehahafall_service_partners' );


/**
 * Site CTA Common Section: [minnehahafall_CTA_section]
 */
function minnehahafall_CTA_section() {
	ob_start(); 
	$cta_section_title = get_theme_mod( 'cta_section_title', true );
    $cta_section_phone = get_theme_mod( 'cta_section_phone', true );
    $cta_section_button_link = get_theme_mod( 'cta_section_button_link', true );
    if ($cta_section_title !='' && $cta_section_phone !='' && $cta_section_button_link !='' ) { ?>
    <section class="section-wrapper call-us">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6 col-lg-6">
                    <div class="call-inner">
                        <h3><?php echo $cta_section_title; ?></h3>
                        <h4>Call us at <a href="tel:<?php echo $cta_section_phone; ?>"><?php echo $cta_section_phone; ?></a></h4>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-6">
                    <div class="call-btn">
                        <a href="<?php echo $cta_section_button_link; ?>">Get a Quote</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php }
	
	return ob_get_clean();
}
add_shortcode( 'minnehahafall_CTA_section', 'minnehahafall_CTA_section' );

 



add_action( 'init', 'minnehahafall_reviews' );
// The custom function to register a custom article post type
function minnehahafall_reviews() {
	
    $labels = array(
        'name'               => __( 'Review' ),
        'singular_name'      => __( 'Review' ),
        'add_new'            => __( 'Add New Review' ),
        'add_new_item'       => __( 'Add New Review' ),
        'edit_item'          => __( 'Edit Review' ),
        'new_item'           => __( 'New Review' ),
        'all_items'          => __( 'All Reviews' ),
        'view_item'          => __( 'View Reviews' ),
        'search_items'       => __( 'Search Review' ),
        'featured_image'     => 'Poster',
        'set_featured_image' => 'Add Poster'
    );
	
    $args = array(
        'labels'            => $labels,
        'description'       => 'Holds our Reviews post specific data',
        'public'            => true,
        'menu_position'     => 5,
        'supports'          => array( 'title', 'custom-fields' ),
        'has_archive'       => true,
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => true,
        'query_var'         => true,
    );
	
    register_post_type('reviews', $args);
}



/**
 * Client Reviews: [minnehahafall_client_reviews]
 */
function minnehahafall_client_reviews() {
	ob_start();  
	?>
	<div class="review-slider">
		<h3 class="testimonial-header">People are talking about us!</h3>
		<div class="tslider">
			<?php
			$reviews = get_posts( array( 'post_type' => 'reviews', 'posts_per_page' => -1, 'orderby'=> 'date', 'order' => 'ASC' ) );
			if( $reviews ):
			foreach( $reviews as $post ) : 
				$message = get_field( "message", $post->ID); 
				if ($message != '') { 
					?>
					<div class="item">
						<p><?php echo $message ; ?></p>
						<p><em>- <?php echo $post->post_title; ?></em></p>
					</div> 
					<?php
				}
				endforeach; 
			wp_reset_postdata(); 
			endif;
			?>
		</div>
	</div>
    <?php	
	return ob_get_clean();
}
add_shortcode( 'minnehahafall_client_reviews', 'minnehahafall_client_reviews' );



add_action( 'init', 'minnehahafall_case_studies' );
// The custom function to register a custom article post type
function minnehahafall_case_studies() {
	
    $labels = array(
        'name'               => __( 'Case Study' ),
        'singular_name'      => __( 'Case Study' ),
        'add_new'            => __( 'Add New Case Study' ),
        'add_new_item'       => __( 'Add New Case Study' ),
        'edit_item'          => __( 'Edit Case Study' ),
        'new_item'           => __( 'New Case Study' ),
        'all_items'          => __( 'All Case Study' ),
        'view_item'          => __( 'View Case Study' ),
        'search_items'       => __( 'Search Case Study' ),
        'featured_image'     => 'Poster',
        'set_featured_image' => 'Add Poster'
    );
	
    $args = array(
        'labels'            => $labels,
        'description'       => 'Holds our Case Study post specific data',
        'public'            => true,
        'menu_position'     => 5,
        'supports'          => array( 'title', 'custom-fields' ),
        'has_archive'       => true,
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => true,
        'query_var'         => true,
    );
	
    register_post_type('case_studies', $args);
}
