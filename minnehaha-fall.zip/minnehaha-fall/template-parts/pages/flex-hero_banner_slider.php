<?php 

$section_id = get_sub_field('section_id');
$section_class = get_sub_field('section_class');
$banner_title = get_sub_field('banner_title');
$banner_description = get_sub_field('banner_description');
$banner_cta_link = get_sub_field('banner_cta_link');
?>
<section id="<?php echo $section_id; ?>" class="banner <?php echo $section_class; ?>">
    <div class="banner">
        <div class="bslider">
            <?php
            $count = 0;
            if( have_rows('banner_item_list') ):
            while( have_rows('banner_item_list') ): the_row();
                $name = get_sub_field('name');
                $link = get_sub_field('link');
                $image = get_sub_field('image');
                if ($name !='' && $image != '') {
                    ?>
                    <div class="item">
                        <img src="<?php echo $image ?>" alt="Image">
                        <div class="inner-wrap">
                            <?php
                            if ($link !='') {
                                echo '<a href="'.$link.'" target=""><span class="title">'.$name.'</span> </a>';
                            } else {
                                echo '<a href="javascript:void(0);" target=""> <span class="title">'.$name.'</span> </a>';
                            } ?>                           
                        </div>
                    </div>
                    <?php
                }
                $count++;
            endwhile;
            endif;
            ?>
        </div>
        <?php
        if ($banner_title !='' && $banner_description !='' ) {
            ?>
            <div class="banner-text">
                <span class="file-description">
                    <h4><?php echo $banner_title; ?></h4>
                    <?php 
                    if ($banner_cta_link !='') { ?>
                        <a href="<?php echo $banner_cta_link; ?>">
                            <h3><?php echo $banner_description; ?></h3>
                        </a>
                    <?php } ?>
                </span>
            </div>
        <?php } ?>
    </div>
</section>