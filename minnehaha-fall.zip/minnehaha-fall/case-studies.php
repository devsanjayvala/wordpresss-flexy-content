<?php
/* Template Name: Case-Studies Page Template */ 

 
get_header();

// Get the directory URI of the child theme
$child_theme_uri = get_stylesheet_directory_uri();
?>
 
<div class="main-wrapper">
    <div class="container">
        <div class="about-content">
            <div class="content">
                <h1>Case Studies</h1>
            </div>
        </div>
    </div>
    <section class="casestudy">
        <div class="container">
            <div class="row">
            <?php
				$case_studies = get_posts( array( 'post_type' => 'case_studies', 'posts_per_page' => -1, 'orderby'=> 'date', 'order' => 'ASC' ) );
				if( $case_studies ):
				foreach( $case_studies as $post ) :  
                    $banner_image = get_field( "banner_image", $post->ID);
                    $page_title = get_field( "page_title", $post->ID);
                    $page_description = get_field( "page_description", $post->ID);                    
                    ?>
                    <div class="col-12 col-md-6 col-lg-6">
                        <div class="casestudy-item">
                            <img src="<?php echo $banner_image; ?>" alt="Image">
                            <h4><?php echo $page_title ?></h4>
                            <?php echo $page_description ?>
                            <div class="readmore">
                                <a href="fsfsdf<?php echo esc_url( get_permalink($post->ID) ) ?>"> Read More <i class="material-icons card-action__icon">arrow_forward</i></a>
                            </div>
                        </div>
                    </div>  <?php
					endforeach; 
				wp_reset_postdata(); 
				endif;
				?> 
                <div class="col-12 col-md-6 col-lg-6">
                    <div class="casestudy-item">
                        <img src="https://valainfotech.com/projects/minnehahafallslandscape/wp-content/uploads/2024/02/mothersgardenhero.k.png" alt="Image">
                        <h4>My Mother’s Garden </h4>
                        <p> The story of a perennial garden where friendship blossomed In 2008, Audrey Peham scheduled a consultation with Minnehaha Fal... </p>
                        <div class="readmore">
                            <a href="#"> Read More <i class="material-icons card-action__icon">arrow_forward</i></a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-6">
                    <div class="casestudy-item">
                        <img src="https://valainfotech.com/projects/minnehahafallslandscape/wp-content/uploads/2024/02/mothersgardenhero.k.png" alt="Image">
                        <h4>A Foundation for Tranquility in a Lovely Backyard</h4>
                        <p> Client Overview Chris Dall and Christen Thompson spend a lot of time tending to their beautiful backyard landscape. After al... </p>
                        <div class="readmore">
                            <a href="#"> Read More <i class="material-icons card-action__icon">arrow_forward</i></a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-6">
                    <div class="casestudy-item">
                        <img src="https://valainfotech.com/projects/minnehahafallslandscape/wp-content/uploads/2024/02/mothersgardenhero.k.png" alt="Image">
                        <h4>New Patio Extends Entertainment Space</h4>
                        <p> Client Overview After 30 years in her Minneapolis home, Polly Jacobson was in the mood for a change in the outdoor landscape... </p>
                        <div class="readmore">
                            <a href="#"> Read More <i class="material-icons card-action__icon">arrow_forward</i></a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-6">
                    <div class="casestudy-item">
                        <img src="https://valainfotech.com/projects/minnehahafallslandscape/wp-content/uploads/2024/02/mothersgardenhero.k.png" alt="Image">
                        <h4>A Backyard Comes to Life After 40 Years</h4>
                        <p> Client Overview In 2020, Cindy Rasmussen and her husband, Dan Molitor installed a new deck on their 1915 Minneapolis home. T... </p>
                        <div class="readmore">
                            <a href="#"> Read More <i class="material-icons card-action__icon">arrow_forward</i></a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-6">
                    <div class="casestudy-item">
                        <img src="https://valainfotech.com/projects/minnehahafallslandscape/wp-content/uploads/2024/02/mothersgardenhero.k.png" alt="Image">
                        <h4>A Beekeeper’s Backyard is All a Buzz!</h4>
                        <p> Client Overview If you taste the honey from Mark and Melissa Van Holland’s bees, you’ll understand why they want to harvest ... </p>
                        <div class="readmore">
                            <a href="#"> Read More <i class="material-icons card-action__icon">arrow_forward</i></a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-6">
                    <div class="casestudy-item">
                        <img src="https://valainfotech.com/projects/minnehahafallslandscape/wp-content/uploads/2024/02/mothersgardenhero.k.png" alt="Image">
                        <h4>Backyard Magic is Real for a Minneapolis Couple</h4>
                        <p> Client Overview Ellen Ryan and Eric Hanson said when they moved into their cozy Minneapolis home a year ago, their backyard ... </p>
                        <div class="readmore">
                            <a href="#"> Read More <i class="material-icons card-action__icon">arrow_forward</i></a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-6">
                    <div class="casestudy-item">
                        <img src="https://valainfotech.com/projects/minnehahafallslandscape/wp-content/uploads/2024/02/mothersgardenhero.k.png" alt="Image">
                        <h4>Drought Sprouts Prairie Meadow and Bee Lawn in Falcon Heights</h4>
                        <p> Client Overview The drought of 2021 killed a big part of John and Kris Robertson-Smith’s lawn in the front yard of their Fal... </p>
                        <div class="readmore">
                            <a href="#"> Read More <i class="material-icons card-action__icon">arrow_forward</i></a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-6">
                    <div class="casestudy-item">
                        <img src="https://valainfotech.com/projects/minnehahafallslandscape/wp-content/uploads/2024/02/mothersgardenhero.k.png" alt="Image">
                        <h4>Paving a Functional Pathway and Patio for Family Fun</h4>
                        <p> Client Overview Erin O’Brien and Alex Schneeman needed to replace the existing backyard patio at their St. Paul home. Erin s... </p>
                        <div class="readmore">
                            <a href="#"> Read More <i class="material-icons card-action__icon">arrow_forward</i></a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-6">
                    <div class="casestudy-item">
                        <img src="https://valainfotech.com/projects/minnehahafallslandscape/wp-content/uploads/2024/02/mothersgardenhero.k.png" alt="Image">
                        <h4>Edina Man Steps Up in Style with New Retaining Wall and Stairs</h4>
                        <p> Client Overview After 30-years in his Edina home, Jim R. was having issues with a retaining wall that had shifted over the y... </p>
                        <div class="readmore">
                            <a href="#"> Read More <i class="material-icons card-action__icon">arrow_forward</i></a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-6">
                    <div class="casestudy-item">
                        <img src="https://valainfotech.com/projects/minnehahafallslandscape/wp-content/uploads/2024/02/mothersgardenhero.k.png" alt="Image">
                        <h4>Walking a New Path to Functional Landscaping and a Pollinator Garden</h4>
                        <p> Client Overview Ryan and Meghan Lindberg have lived in their Highland home for three years, and it was time to spruce up the... </p>
                        <div class="readmore">
                            <a href="#"> Read More <i class="material-icons card-action__icon">arrow_forward</i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Service Partners -->
    <?php echo do_shortcode( '[minnehahafall_service_partners]' ); ?> 

    <section class="section-wrapper contact-us">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="cform contact-form">
                        <h2>Get in Touch</h2>
                        <p>Call us at&nbsp;<a href="http://612-724-5454/">612-724-5454</a>&nbsp;to see what is possible with landscape design and construction, organic gardening, and indoor remodeling.</p>
                        <?php echo do_shortcode( '[contact-form-7 id="a33b622" title="Contact Form for all pages"]' ); ?> 
                    </div>
                </div>
                <div class="col-12 col-md-6">                
                <?php echo do_shortcode( '[minnehahafall_client_reviews]' ); ?> 
                </div>
            </div>
        </div>
    </section>

    <!-- SIte CTA Section -->
    <?php echo do_shortcode( '[minnehahafall_CTA_section]' ); ?> 

</div>           
    

<?php
get_footer();