<?php
/* Template Name: 02 About Us Page Template */ 

 
get_header();

// Get the directory URI of the child theme
$child_theme_uri = get_stylesheet_directory_uri();
 
$page_id = get_the_ID();
$banner_title = get_field( "banner_title", $page_id);
$banner_description = get_field( "banner_description", $page_id);
$banner_image = get_field( "banner_image", $page_id);
// $banner_cta_link = get_field( "banner_cta_link", $page_id);
 
?>
<div class="main-wrapper">
    <section class="about-banner">
        <img src="<?php echo $banner_image; ?>" alt="Image">
    </section>
    <section class="section-wrapper about-content">
        <div class="container">
            <div class="row">
            <?php
            if ($banner_title !='' && $banner_description !='' ) {
                ?>
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="content">
                        <h1><?php echo $banner_title; ?></h1>
                        <?php echo $banner_description; ?>
                    </div>
                </div>
            <?php } ?>
            </div>
        </div>
    </section>

    
    <section class="section-wrapper service about">
        <div class="container">
            <div class="row top-wrapper">
                <?php
                if( have_rows('counter_list') ):
                while( have_rows('counter_list') ): the_row();
                    $icon = get_sub_field('icon');
                    $number = get_sub_field('number');
                    $name = get_sub_field('name'); 
                    
                    if ($icon !='' && $number != '' && $name != '') {
                        ?>  
                        <div class="col-12 col-md-6 col-lg-3 p-0">
                            <div class="service-item">
                                <div class="service-image">
                                    <img src="<?php echo $icon ?>" alt="Image">
                                </div>
                                <div class="service-content">
                                    <h2><?php echo $number ?></h2>
                                    <h3><?php echo $name ?></h3>
                                </div>
                            </div>
                        </div>
                        <?php
                    } 
                endwhile;
                endif;
                ?>
            </div> 
        </div>
    </section>
    <?php
    $our_story_title = get_field( "our_story_title", $page_id);
    $our_story_description = get_field( "our_story_description", $page_id);
    $vimeo_video_link = get_field( "vimeo_video_link", $page_id);
    // $banner_cta_link = get_field( "banner_cta_link", $page_id);
     
    ?>
    <section class="section-wrapper about-content">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="content">
                        <h2><?php echo $our_story_title; ?></h2>
                        <div class="content-video">
                            <div class="content-video-inner">
                                <iframe src="<?php echo $vimeo_video_link; ?>" width="100%" height="100%" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen=""></iframe>
                            </div>
                        </div>
                        <?php echo $our_story_description; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Service Partners -->
    <?php echo do_shortcode( '[minnehahafall_service_partners]' ); ?> 

    <section class="section-wrapper contact-us">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="cform contact-form">
                        <h2>Get in Touch</h2>
                        <?php echo do_shortcode( '[contact-form-7 id="a33b622" title="Contact Form for all pages"]' ); ?> 
                    </div>
                </div>
                <div class="col-12 col-md-6">                
                <?php echo do_shortcode( '[minnehahafall_client_reviews]' ); ?> 
                </div>
            </div>
        </div>
    </section>

    <!-- SIte CTA Section -->
    <?php echo do_shortcode( '[minnehahafall_CTA_section]' ); ?>

</div>

<?php
get_footer();