<?php
/* Template Name: Service Minnehaha Remodeling Page Template */ 
 
get_header();

// Get the directory URI of the child theme
$child_theme_uri = get_stylesheet_directory_uri();

$page_id = get_the_ID();
$banner_image = get_field( "banner_image", $page_id);
$banner_title = get_field( "banner_title", $page_id);
$banner_sub_title = get_field( "banner_sub_title", $page_id);
$request_a_quote_link = get_field( "request_a_quote_link", $page_id);
$remodeling_logo = get_field( "remodeling_logo", $page_id);
$remodeling_description = get_field( "remodeling_description", $page_id);

$step_inside_title = get_field( "step_inside_title", $page_id);
$step_inside_description = get_field( "step_inside_description", $page_id);
$step_inside_image = get_field( "step_inside_image", $page_id);
$step_outside_title = get_field( "step_outside_title", $page_id);
$step_inside_description = get_field( "step_inside_description", $page_id);
?>
 
 <div class="main-wrapper">
 
    <section class="about-banner">
        <img src="<?php echo $banner_image; ?>" alt="Image">
        <div class="banner-text">
            <div class="banner-text-inner">
                <h1><?php echo $banner_title; ?> </h1>
                <h2><?php echo $banner_sub_title; ?></h2>
                <a href="<?php echo $request_a_quote_link; ?>" tabindex="0"><p>Request a Quote </p></a>
            </div>
    	</div>
    </section>
    <section class="section-wrapper about-content">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="content">
                        <div class="about-logo">
                            <img src="<?php echo $remodeling_logo; ?>" alt="Image">
                            <p><?php echo $remodeling_description; ?></p>
                        </div>
                        <div class="service-inside-step">
                            <div class="step-content">
                                <h2><strong>STEP INSIDE!</strong></h2>
                                <h3><strong><?php echo $step_inside_title; ?></strong></h3>
                                <?php echo $step_inside_description; ?>
                            </div>
                            <div class="step-image">
                                <img src="<?php echo $step_inside_image; ?>" alt="Image">
                            </div>
                        </div> 
                        <div class="service-inside-step slider">
                            <div class="step-image">
                            <?php
                                if( have_rows('step_outside_images') ):
                                    while( have_rows('step_outside_images') ): the_row(); 
                                        $image = get_sub_field('image');
                                        if ($image !='') { 
                                            ?>
                                            <div class="slide">
                                                <img src="<?php echo $image; ?>" alt="Image">
                                            </div>
                                        <?php
                                        }
                                    endwhile;
                                endif;
                                ?>
                            </div>
                            <div class="step-content">
                                <h2><strong>STEP OUTSIDE!</strong></h2>
                                <h3><strong><?php echo $step_outside_title; ?></strong></h3>
                                <?php echo $step_inside_description; ?>
                            </div>
                        </div>                        
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Service Partners -->
    <?php echo do_shortcode( '[minnehahafall_service_partners]' ); ?> 

    <section class="section-wrapper contact-us">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="cform contact-form">
                        <h2>Get in Touch</h2>
                        <?php echo do_shortcode( '[contact-form-7 id="a33b622" title="Contact Form for all pages"]' ); ?> 
                    </div>
                </div>
                <div class="col-12 col-md-6">                
                <?php echo do_shortcode( '[minnehahafall_client_reviews]' ); ?> 
                </div>
            </div>
        </div>
    </section>

    <!-- SIte CTA Section -->
    <?php echo do_shortcode( '[minnehahafall_CTA_section]' ); ?>

</div> 

<?php
get_footer();