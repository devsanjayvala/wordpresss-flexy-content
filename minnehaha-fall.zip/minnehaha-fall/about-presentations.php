<?php
/* Template Name: About - Presentations Page Template */ 
 
get_header();

// Get the directory URI of the child theme
$child_theme_uri = get_stylesheet_directory_uri();

$page_id = get_the_ID();
$banner_image = get_field( "banner_image", $page_id);
$banner_title = get_field( "banner_title", $page_id);
$page_description_1 = get_field( "page_description_1", $page_id);
$page_description_2 = get_field( "page_description_2", $page_id);
$presentation_image = get_field( "presentation_image", $page_id);
$presentation_description_1 = get_field( "presentation_description_1", $page_id);
$presentation_description_2 = get_field( "presentation_description_2", $page_id);
$presentation_description_3 = get_field( "presentation_description_3", $page_id);
$presentation_qoute = get_field( "presentation_qoute", $page_id);
// $banner_cta_link = get_field( "banner_cta_link", $page_id); 
?>
 
 <div class="main-wrapper">
    <section class="about-banner presen-banner">
        <img src="https://valainfotech.com/projects/minnehahafallslandscape/wp-content/uploads/2024/02/presentation.png" alt="Image">
        <div class="banner-text">
            <div class="banner-text-inner">
                <div class="container">
                    <h1>Book <br><strong>Russ Henry</strong> for a Bee <br>Friendly Lawn Presentation</h1>
                </div>        
            </div>
    	</div>
    </section>
    <section class="section-wrapper about-content">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="content">
                        <h2>75% of the world’s plants and 30% of human food crops depend on bees and other pollinators to reproduce, but many species are facing extinction.</h2>
                        <div class="event-wrap">
                            <div class="event-para">
                                <p><strong>Encourage residents of your community to have a profound impact on bee health by transitioning from mowing and pesticides to a bee lawn.</strong></p>
                                <p>Russ Henry is an author and presenter, founder of Bee Safe Minneapolis, and owner of Minnehaha Falls Landscaping. He presents for the Minnesota State Horticultural Society, and his presentations have been well received by foundations, garden clubs, the Minnesota Nursery and Landscape Association, The Minneapolis Home Show, churches, schools, colleges, businesses, organizations, government agencies and departments, and The Minnesota State Fair. Russ has been featured in the Minneapolis Star Tribune and other publications around the country.</p>
                            </div>
                            <div class="events-box">
                                <div class="events-item">
                                    <div class="event-header">
                                    <h3>Upcoming Events</h3>
                                    </div>
                                    <div class="event-content">
                                    <div class="item">
                                        <a href="http://www.dakotagardeners.org/upcoming-events.html" target="_blank">
                                            <p> February 21st - 7:00 pm </p>
                                            <p> South St. Paul High School Lecture Hall </p>
                                            <p><strong> Dakota Gardens Gardening Club – Bee Lawn Installation &amp; Management </strong></p>
                                        </a>
                                    </div>
                                    <div class="item">
                                        <a href="https://www.homeandgardenshow.com" target="_blank">
                                            <p> Feb. 23rd – Noon-1:00 </p>
                                            <p> Minneapolis Convention Center - Main Stage </p>
                                            <p><strong> Home and Garden Show – Bee Lawn Installation &amp; Management </strong></p>
                                        </a>
                                    </div>
                                    <div class="item">
                                        <a href="https://www.facebook.com/PineCountyMasterGardeners/" target="_blank">
                                            <p> March 16th - Time TBD </p>
                                            <p> TBD </p>
                                            <p><strong> Pine County Master Gardeners – Pesticide Free Landscaping </strong></p>
                                        </a>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="presentation">
                            <div class="presentation-image">
                                <img src="https://valainfotech.com/projects/minnehahafallslandscape/wp-content/uploads/2024/02/web-russ-111v2.jpg" alt="">
                            </div>
                            <div class="presentation-content">
		                        <h3>A one-hour, no cost presentation is available to:</h3>
                                <ul>
                                    <li>City and state governments</li>
                                    <li>Health departments</li>
                                    <li>Parks and recreation</li>
                                    <li>Garden clubs</li>
                                    <li>Schools Administrators</li>
                                    <li>Sustainability departments</li>
                                    <li>Community education programs</li>
                                    <li>Community organizations</li>
                                    <li>Churches</li>
                                    <li>Businesses</li>
                                </ul>
                            </div>
                        </div>
                        <div class="text-center">
                            <h5>(Presentation time can be adjusted, based on your schedule)</h5>
                            <h2>Book Russ Henry today!<br>Call Kari Logan at 612-998-0955<br>or email <a href="emailto:klogan@minnehahafallslandscape.com">klogan@minnehahafallslandscape.com</a></h2>
                            <p><strong>Other presentation topics include creation care, soil health, native plantings for sun or shade, and food forests</strong></p>
                        </div>
                        <div class="imaeg-gallery row">
                            <div class="col-12 col-md-6 col-lg-6 mb-4">
                                <img src="https://valainfotech.com/projects/minnehahafallslandscape/wp-content/uploads/2024/02/rain-garden-landscape.k.jpeg" alt="">
                            </div>
                            <div class="col-12 col-md-6 col-lg-6 mb-4">
                                <img src="https://valainfotech.com/projects/minnehahafallslandscape/wp-content/uploads/2024/02/healthy-soil-blog-landscape.k.jpeg" alt="">
                            </div>
                        </div>
                        <h2>People are talking about Russ Henry’s presentation</h2>
                        <p><strong>Russ was amazing!</strong> - Pastor Mary Koon, Bloomington</p>
                        <p><strong>Russ’ presence and presentation was well received both for the information it contained and for his engaging style</strong>. - Randy Nelson, Minneapolis</p>
                        <p><strong>We thoroughly enjoyed Russ’ presentation! People came up to me after, and throughout the week telling me how much they enjoyed it.</strong> - Katie Hein, Edina</p>
                        <p><strong>The talk Russ gave was great! The attendees were very engaged in what he had to say. He’s knowledgeable and gave us some great thoughts on what we can do in our own spaces!</strong> - Mary Learmont, Minneapolis</p>
                        <div class="qoute">
                            <h3><strong>Anything we do to take responsibility for the health of our little corner this planet is a gift we give for generations to come.”</strong> – Russ Henry</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Service Partners -->
    <?php echo do_shortcode( '[minnehahafall_service_partners]' ); ?> 

    <section class="section-wrapper contact-us">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="cform contact-form">
                        <h2>Get in Touch</h2>
                        <?php echo do_shortcode( '[contact-form-7 id="a33b622" title="Contact Form for all pages"]' ); ?> 
                    </div>
                </div>
                <div class="col-12 col-md-6">                
                <?php echo do_shortcode( '[minnehahafall_client_reviews]' ); ?> 
                </div>
            </div>
        </div>
    </section>

    <!-- SIte CTA Section -->
    <?php echo do_shortcode( '[minnehahafall_CTA_section]' ); ?>

</div>

<?php
get_footer();