<?php
/* Template Name: Sustainability Backyard Hero Page Template */ 
 
get_header();
?>
<style>
.vimeo-shadowbox {
  position: fixed;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  z-index: 1000;
  background: rgba(0, 0, 0, 0.7);
  transition: all 0.5s ease;
}
.vimeo-shadowbox--hidden {
  opacity: 0;
  z-index: -1000;
  visibility: hidden;
  pointer-events: none;
}
.vimeo-shadowbox__video-wrapper {
  position: fixed;
  width: 100%;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  width: 100%;
  max-width: 980px;
}
.vimeo-shadowbox__video {
  position: relative;
  padding-bottom: 56.25%;
  /* 16:9 */
  padding-top: 25px;
  height: 0;
}
.vimeo-shadowbox__video iframe {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
}
.vimeo-shadowbox__close-button {
  width: 30px;
  height: 30px;
  border: 1px solid #fff;
  border-radius: 50%;
  position: absolute;
  right: -15px;
  top: -15px;
  overflow: hidden;
  text-indent: -9999em;
  background: #000;
}
</style>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.css" />

<?php
// Get the directory URI of the child theme
$child_theme_uri = get_stylesheet_directory_uri();

$page_id = get_the_ID();
$banner_image = get_field( "banner_image", $page_id);
$page_title = get_field( "page_title", $page_id);
$page_description = get_field( "page_description", $page_id);
$page_description_2 = get_field( "page_description_2", $page_id);
$vimeo_video_link = get_field( "vimeo_video_link", $page_id);

?>
 <div class="vimeo-shadowbox vimeo-shadowbox--hidden">
  <div class="vimeo-shadowbox__video-wrapper">
    <div class="vimeo-shadowbox__video">
        <iframe src="https://player.vimeo.com/video/662660552?h=a2af8c0315" width="980" height="550" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>  
    </div>
    <a class="vimeo-shadowbox__close-button" href="#">Close</a>
  </div>
</div>
<div class="main-wrapper"> 
    <section class="about-banner">
		<a class="open-popup-link" href="#">
        <img src="<?php echo $banner_image; ?>" alt="Image">
		</a>
    </section>
    <section class="section-wrapper about-content image-with-video">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6 col-lg-6">
                    <div class="sustainability-content">
                        <h2><?php echo $page_title; ?></h2>
                        <?php echo $page_description; ?>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-6">
                    <div class="sustainability-video">
                        <iframe src="<?php echo $vimeo_video_link; ?>" width="100%" height="100%" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen=""></iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section-wrapper about-content gray-bg">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="graybg-content">
                        <?php echo $page_description_2; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Service Partners -->
    <?php echo do_shortcode( '[minnehahafall_service_partners]' ); ?> 

    <?php
    $form_title = get_field( "form_title", $page_id);
    $form_description = get_field( "form_description", $page_id);
    $form_shortcode = get_field( "form_shortcode", $page_id);
    ?>
    <section class="section-wrapper contact-us">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="cform contact-form">
                        <?php
                        if ($form_title !='' || $form_description !='' || $form_shortcode !='' ) {
                            echo '<h2>'.$form_title.'</h2>';
                            echo $form_description;
                            echo do_shortcode($form_shortcode);
                        }
                        ?> 
                    </div>
                </div>
                <div class="col-12 col-md-6">                
                <?php echo do_shortcode( '[minnehahafall_client_reviews]' ); ?> 
                </div>
            </div>
        </div>
    </section>

    <!-- SIte CTA Section -->
    <?php echo do_shortcode( '[minnehahafall_CTA_section]' ); ?>

</div> 

<?php
get_footer();

?>

<script src="https://player.vimeo.com/api/player.js"></script>
<script>
"use strict";

//https://github.com/vimeo/player.js - documentation

let iframe = document.querySelector("iframe");
let player = new Vimeo.Player(iframe);
let link = document.querySelector(".open-popup-link");
let shadowbox = document.querySelector(".vimeo-shadowbox");
let closeButton = document.querySelector(".vimeo-shadowbox__close-button");

player.on("ended", function () {
  hidePopup();
});

link.addEventListener("click", showPopup);
shadowbox.addEventListener("click", hidePopup);
closeButton.addEventListener("click", hidePopup);

function showPopup() {
  player.play();
  shadowbox.classList.remove("vimeo-shadowbox--hidden");
}
function hidePopup() {
  player.pause();
  shadowbox.classList.add("vimeo-shadowbox--hidden");
}

	
$(function() {
    $('.popup-youtube, .popup-vimeo').magnificPopup({
        disableOn: 700,
        type: 'iframe',
        mainClass: 'mfp-fade',
        removalDelay: 160,
        preloader: false,
        fixedContentPos: false
    });
});
</script>