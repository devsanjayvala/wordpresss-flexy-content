<?php
/* Template Name: Service Lawn Page Template */ 
 
get_header();

// Get the directory URI of the child theme
$child_theme_uri = get_stylesheet_directory_uri();

$page_id = get_the_ID();
$banner_image = get_field( "banner_image", $page_id);
$page_title = get_field( "page_title", $page_id);
$banner_description = get_field( "page_description", $page_id);

?>
 
<div class="main-wrapper">
 
    <section class="about-banner">
        <img src="<?php echo $banner_image; ?>" alt="Image">
    </section>
    <section class="section-wrapper about-content">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="content">
                        <h1><?php echo $page_title; ?></h1>
                        <?php echo $banner_description; ?>
                        <div class="imaeg-gallery row">
                            <?php
                            if( have_rows('service_images') ):
                                while( have_rows('service_images') ): the_row(); 
                                    $image = get_sub_field('image');
                                    if ($image !='') { 
                                            ?>
                                            <div class="col-12 col-md-6 col-lg-6 mb-4">
                                                <img src="<?php echo $image; ?>" alt="">
                                            </div>
                                        <?php
                                    }
                                endwhile;
                            endif;
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Service Partners -->
    <?php echo do_shortcode( '[minnehahafall_service_partners]' ); ?> 

    <section class="section-wrapper contact-us">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="cform contact-form">
                        <h2>Get in Touch</h2>
                        <?php echo do_shortcode( '[contact-form-7 id="a33b622" title="Contact Form for all pages"]' ); ?> 
                    </div>
                </div>
                <div class="col-12 col-md-6">                
                <?php echo do_shortcode( '[minnehahafall_client_reviews]' ); ?> 
                </div>
            </div>
        </div>
    </section>

    <!-- SIte CTA Section -->
    <?php echo do_shortcode( '[minnehahafall_CTA_section]' ); ?>

</div> 

<?php
get_footer();