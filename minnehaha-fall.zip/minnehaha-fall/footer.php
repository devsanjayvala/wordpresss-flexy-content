<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

?>
			</main><!-- #main -->
		</div><!-- #primary -->
	</div><!-- #content -->

	<?php get_template_part( 'template-parts/footer/footer-widgets' ); ?>

	<footer id="colophon" class="site-footer">

		<div class="container">
			<div class="row">
				<div class="col-12 col-sm-12 col-md-3 col-lg-3">
					<div class="site-name">
						<?php if ( has_custom_logo() ) : ?>
							<div class="site-logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php the_custom_logo(); ?></a></div>
						<?php endif; ?>
					</div>
				</div>
				<div class="col-12 col-sm-12 col-md-3 col-lg-3">
					<div class="footer-menu footer-links">
						<h2>Quick Links</h2>
						<div class="footer-menus ">
							<?php if ( has_nav_menu( 'footer-menu-1' ) ) : ?>
								<nav aria-label="<?php esc_attr_e( 'Secondary menu', 'twentytwentyone' ); ?>" class="footer-navigation">
									<ul class="footer-navigation-wrapper">
										<?php
										wp_nav_menu(
											array(
												'theme_location' => 'footer-menu-1',
												'items_wrap'     => '%3$s',
												'container'      => false,
												'depth'          => 1,
												'link_before'    => '<span>',
												'link_after'     => '</span>',
												'fallback_cb'    => false,
											)
										);
										?>
									</ul><!-- .footer-navigation-wrapper -->
								</nav><!-- .footer-navigation -->
							<?php endif; ?>
						</div>
					</div>
				</div>
				<div class="col-12 col-sm-12 col-md-3 col-lg-3">
					<div class="footer-menu footer-links">
						<h2>Services</h2>
						<div class="footer-menus">
							<?php if ( has_nav_menu( 'footer-menu-2' ) ) : ?>
								<nav aria-label="<?php esc_attr_e( 'Secondary menu', 'twentytwentyone' ); ?>" class="footer-navigation">
									<ul class="footer-navigation-wrapper">
										<?php
										wp_nav_menu(
											array(
												'theme_location' => 'footer-menu-2',
												'items_wrap'     => '%3$s',
												'container'      => false,
												'depth'          => 1,
												'link_before'    => '<span>',
												'link_after'     => '</span>',
												'fallback_cb'    => false,
											)
										);
										?>
									</ul><!-- .footer-navigation-wrapper -->
								</nav><!-- .footer-navigation -->
							<?php endif; ?>
						</div>
					</div>
				</div>
				<div class="col-12 col-sm-12 col-md-3 col-lg-3">
					<div class="footer_contact_info footer-menu">
						<h2>Contact Info</h2>
						<div class="contact_info">
							<span>Email: <a href="emailto:info@minnehahafallslandscape.com">info@minnehahafallslandscape.com</a></span>
							<span>Call Us: <a href="tel:612-724-5454">612-724-5454</a></span>
						</div>
						<div class="footer_social">
							<a href="https://www.facebook.com/MinnehahaFallsLandscaping/"  target="_blank"><span class="material-icons-outlined">facebook</span></a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="site-info">
			<div class="powered-by">© 2024. All rights reserved by <a href="<?php echo esc_url( home_url( '/' ) ); ?>">Minnehaha Falls Landscaping</a></div>
			<!-- .powered-by -->
		</div><!-- .site-info -->
	</footer><!-- #colophon -->

</div><!-- #page -->

<?php wp_footer(); ?>
<script>
// Banner Slider
jQuery(document).ready(function(){
    jQuery('.bslider').slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay: true,
		infinite: false,
        autoplaySpeed: 2500,
        arrows: false,
        dots: false,
        pauseOnHover: false,
        responsive: [{
            breakpoint: 991,
            settings: {
                slidesToShow: 2,
				slidesToScroll: 1,
				arrows: false,
        		dots: false,
            }
        },
         {
            breakpoint: 768,
            settings: {
                slidesToShow: 2,
				slidesToScroll: 1,
				arrows: false,
        		dots: false,
            }
        },
        {
            breakpoint: 600,
            settings: {
                slidesToShow: 1,
				slidesToScroll: 1,
				arrows: false,
        		dots: false,
            }
        }]
    });
});
// Review Slider
jQuery(document).ready(function(){
    jQuery('.tslider').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
		infinite: false,
        autoplaySpeed: 2500,
        arrows: false,
        dots: true,
        pauseOnHover: false,
        responsive: [{
            breakpoint: 800,
            settings: {
                slidesToShow: 1,
				slidesToScroll: 1,
				arrows: false,
        		dots: true,
            }
        }, {
            breakpoint: 768,
            settings: {
                slidesToShow: 1,
				slidesToScroll: 1,
				arrows: false,
        		dots: true,
            }
        }]
    });
});
// Step slider
jQuery(document).ready(function(){
    jQuery('.stepslider').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
		infinite: false,
        autoplaySpeed: 2500,
        arrows: true,
        dots: false,
        pauseOnHover: false,
        responsive: [{
            breakpoint: 800,
            settings: {
                slidesToShow: 1,
				slidesToScroll: 1,
				arrows: false,
        		dots: false,
            }
        }, {
            breakpoint: 768,
            settings: {
                slidesToShow: 1,
				slidesToScroll: 1,
				arrows: false,
        		dots: false,
            }
        }]
    });
});

// Step Inside Slider
jQuery(document).ready(function(){
    jQuery('.step-image').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
		infinite: false,
        autoplaySpeed: 2500,
        arrows: true,
        dots: true,
        pauseOnHover: false,
        responsive: [{
            breakpoint: 800,
            settings: {
                slidesToShow: 1,
				slidesToScroll: 1,
				arrows: true,
        		dots: true,
            }
        }, {
            breakpoint: 768,
            settings: {
                slidesToShow: 1,
				slidesToScroll: 1,
				arrows: true,
        		dots: true,
            }
        }]
    });
});

// Banner Slider
jQuery(document).ready(function(){
    jQuery('.banner-slide').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
		infinite: false,
        autoplaySpeed: 2500,
        arrows: true,
        dots: false,
        pauseOnHover: false,
        responsive: [{
            breakpoint: 800,
            settings: {
                slidesToShow: 1,
				slidesToScroll: 1,
				arrows: true,
        		dots: false,
            }
        }, {
            breakpoint: 768,
            settings: {
                slidesToShow: 1,
				slidesToScroll: 1,
				arrows: true,
        		dots: false,
            }
        }]
    });
});
</script>
</body>
</html>
