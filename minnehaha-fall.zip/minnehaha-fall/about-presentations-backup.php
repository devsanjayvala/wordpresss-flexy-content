<?php
/* Template Name: Backup About - Presentations Page Template */ 
 
get_header();

// Get the directory URI of the child theme
$child_theme_uri = get_stylesheet_directory_uri();

$page_id = get_the_ID();
$banner_image = get_field( "banner_image", $page_id);


$banner_title = get_field( "banner_title", $page_id);
$page_description_1 = get_field( "page_description_1", $page_id);
$page_description_2 = get_field( "page_description_2", $page_id);
$presentation_image = get_field( "presentation_image", $page_id);
$presentation_description_1 = get_field( "presentation_description_1", $page_id);
$presentation_description_2 = get_field( "presentation_description_2", $page_id);
$presentation_description_3 = get_field( "presentation_description_3", $page_id);
$presentation_qoute = get_field( "presentation_qoute", $page_id);
// $banner_cta_link = get_field( "banner_cta_link", $page_id);

?>
 
 <div class="main-wrapper">
    <section class="about-banner presen-banner">
        <img src="<?php echo $banner_image; ?>" alt="Image">
        <div class="banner-text">
            <div class="banner-text-inner">
                <div class="container">
                    <?php echo $banner_title; ?>
                </div>        
            </div>
    	</div>
    </section>
    <section class="section-wrapper about-content">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="content">
                        <?php 
                        if ($page_description_1 !='') {
                            echo $page_description_1;
                        }
                        ?>
                        <div class="event-wrap">
                            <div class="event-para">
                                <?php 
                                if ($page_description_2 !='') {
                                    echo $page_description_2;
                                }
                                ?>
                            </div>
                            <div class="events-box">
                                <div class="events-item">
                                    <div class="event-header">
                                    <h3>Upcoming Events</h3>
                                    </div>
                                    <div class="event-content">
                                    <?php
                                        if( have_rows('upcoming_events') ):
                                        while( have_rows('upcoming_events') ): the_row();
                                            $link = get_sub_field('link');
                                            $description = get_sub_field('description');                                    
                                            if ($description !='' && $link != '') {
                                                ?>
                                                <div class="item">
                                                    <a href="<?php echo $link ?>" target="_blank">
                                                        <?php echo $description ?>
                                                    </a>
                                                </div>
                                                <?php
                                            } 
                                        endwhile;
                                        endif;
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="presentation">
                            <div class="presentation-image">
                                <img src="<?php echo $presentation_image; ?>" alt="">
                            </div>
                            <div class="presentation-content">
                                <?php 
                                if ($presentation_description_1 !='') {
                                    echo $presentation_description_1;
                                }
                                ?>
                            </div>
                        </div>
                        <div class="text-center">
                            <?php 
                            if ($presentation_description_2 !='') {
                                echo $presentation_description_2;
                            }
                            ?>
                        </div>
                        <div class="imaeg-gallery row">
                            <?php
                            if( have_rows('presentation_gallery') ):
                            while( have_rows('presentation_gallery') ): the_row();
                                $image = get_sub_field('image');                                   
                                if ($image != '') {
                                    ?>
                                    <div class="col-12 col-md-6 col-lg-6 mb-4">
                                        <img src="<?php echo $image ?>" alt="">
                                    </div>
                                    <?php
                                } 
                            endwhile;
                            endif;
                            ?>
                        </div>
                        <?php 
                        if ($presentation_description_3 !='') {
                            echo $presentation_description_3;
                        }
                        ?>
                       <div class="qoute">
                            <?php 
                            if ($presentation_qoute !='') {
                                echo $presentation_qoute;
                            }
                            ?> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Service Partners -->
    <?php echo do_shortcode( '[minnehahafall_service_partners]' ); ?> 

    <?php
    $form_title = get_field( "form_title", $page_id);
    $form_description = get_field( "form_description", $page_id);
    $form_shortcode = get_field( "form_shortcode", $page_id);
    ?>
    <section class="section-wrapper contact-us">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="cform contact-form">
                        <?php
                        if ($form_title !='' || $form_description !='' || $form_shortcode !='' ) {
                            echo '<h2>'.$form_title.'</h2>';
                            echo $form_description;
                            echo do_shortcode($form_shortcode);
                        }
                        ?> 
                    </div>
                </div>
                <div class="col-12 col-md-6">                
                <?php echo do_shortcode( '[minnehahafall_client_reviews]' ); ?> 
                </div>
            </div>
        </div>
    </section>
    <!-- SIte CTA Section -->
    <?php echo do_shortcode( '[minnehahafall_CTA_section]' ); ?>

</div>

<?php
get_footer();