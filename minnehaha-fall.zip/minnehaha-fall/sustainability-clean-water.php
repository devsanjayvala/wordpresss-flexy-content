<?php
/* Template Name: Sustainability Clean Water Page Template */ 
 
get_header();

// Get the directory URI of the child theme
$child_theme_uri = get_stylesheet_directory_uri();
$page_id = get_the_ID();
$banner_image = get_field( "banner_image", $page_id);
$page_title = get_field( "page_title", $page_id);
$page_description = get_field( "page_description", $page_id);

?>
 
<div class="main-wrapper">
 
    <section class="about-banner">
        <img src="<?php echo $banner_image; ?>" alt="Image">
    </section>
    <section class="section-wrapper about-content">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="content">
                        <h2><?php echo $page_title; ?></h2>
                        <?php echo $page_description; ?>

                        <?php
                        if( have_rows('service_images') ):
                            while( have_rows('service_images') ): the_row(); 
                                $title = get_sub_field('title');
                                $description = get_sub_field('description');
                                
                                if ($title !='' && $description !='') { 
                                    ?>
                                    <h3><?php echo $title; ?></h3>
                                    <?php echo $description; ?>
                                    <div class="imaeg-gallery row">
                                        <?php
                                        if( have_rows('images') ):
                                            while( have_rows('images') ): the_row(); 
                                                $image = get_sub_field('image');
                                                if ($image !='') { 
                                                        ?>
                                                        <div class="col-12 col-md-6 col-lg-6 mb-4">
                                                            <img src="<?php echo $image; ?>" alt="">
                                                        </div>
                                                    <?php
                                                }
                                            endwhile;
                                        endif;
                                        ?>
                                    </div>
                                <?php
                                }
                            endwhile;
                        endif;
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Service Partners -->
    <?php echo do_shortcode( '[minnehahafall_service_partners]' ); ?> 

    <?php
    $form_title = get_field( "form_title", $page_id);
    $form_description = get_field( "form_description", $page_id);
    $form_shortcode = get_field( "form_shortcode", $page_id);
    ?>
    <section class="section-wrapper contact-us">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="cform contact-form">
                        <?php
                        if ($form_title !='' || $form_description !='' || $form_shortcode !='' ) {
                            echo '<h2>'.$form_title.'</h2>';
                            echo $form_description;
                            echo do_shortcode($form_shortcode);
                        }
                        ?> 
                    </div>
                </div>
                <div class="col-12 col-md-6">                
                <?php echo do_shortcode( '[minnehahafall_client_reviews]' ); ?> 
                </div>
            </div>
        </div>
    </section>

    <!-- SIte CTA Section -->
    <?php echo do_shortcode( '[minnehahafall_CTA_section]' ); ?>

</div> 

<?php
get_footer();