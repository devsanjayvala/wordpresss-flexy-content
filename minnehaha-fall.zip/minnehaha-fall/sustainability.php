<?php
/* Template Name: Sustainability Page Template */ 

 
get_header();

// Get the directory URI of the child theme
$child_theme_uri = get_stylesheet_directory_uri();

$page_id = get_the_ID();
$banner_image = get_field( "banner_image", $page_id);
$page_title = get_field( "page_title", $page_id);
$page_description = get_field( "page_description", $page_id);
$service_image_1 = get_field( "service_image_1", $page_id);
$service_image_2 = get_field( "service_image_2", $page_id);

?>
 
<div class="main-wrapper">
    <section class="about-banner">
        <img src="<?php echo $banner_image; ?>" alt="Image">
    </section>
    <section class="section-wrapper about-content sustainability">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="content">
                        <h1><?php echo $page_title; ?></h1>
                        <div class="image-content-right">
                            <img src="<?php echo $service_image_1; ?>" alt="">
                        </div>
                        <?php echo $page_description; ?>
                    </div>
                </div>
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="content"> 
                        <div class="image-title-right">
                            <div class="image-title-right-img ">
                                <img src="<?php echo $service_image_2; ?>" alt="">
                            </div>
                        </div>
                        <?php
                        if( have_rows('counter_list') ):
                            while( have_rows('counter_list') ): the_row(); 
                                $number = get_sub_field('number');
                                $name = get_sub_field('name');
                                if ($number !='' && $name !='') { 
                                        ?>
                                        <p><span class="counter"><?php echo $number; ?></span><br><?php echo $name; ?></p>
                                    <?php
                                }
                            endwhile;
                        endif;
                        ?> 
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section-wrapper service service-page">
        <div class="container">
            <div class="row">
                <?php
                if( have_rows('services_list') ):
                    while( have_rows('services_list') ): the_row(); 
                    $name = get_sub_field('name');
                    $description = get_sub_field('description');
                    $link = get_sub_field('link');
                        if ($number !='' && $description !='' && $link !='') { 
                                ?>
                                <div class="col-12 col-md-6 col-lg-3 p-0">
                                    <div class="service-item">
                                        <div class="service-content">
                                            <h3><?php echo $name; ?></h3>
                                            <?php echo $description; ?>
                                            <div class="readmore">
                                                <a href="<?php echo $link; ?>">Read more <i class="material-icons card-action__icon link-arrow">arrow_forward</i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php
                        }
                    endwhile;
                endif;
                ?>
            </div>
        </div>
    </section>
    <!-- Service Partners -->
    <?php echo do_shortcode( '[minnehahafall_service_partners]' ); ?> 

    <?php
    $form_title = get_field( "form_title", $page_id);
    $form_description = get_field( "form_description", $page_id);
    $form_shortcode = get_field( "form_shortcode", $page_id);
    ?>
    <section class="section-wrapper contact-us">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="cform contact-form">
                        <?php
                        if ($form_title !='' || $form_description !='' || $form_shortcode !='' ) {
                            echo '<h2>'.$form_title.'</h2>';
                            echo $form_description;
                            echo do_shortcode($form_shortcode);
                        }
                        ?> 
                    </div>
                </div>
                <div class="col-12 col-md-6">                
                <?php echo do_shortcode( '[minnehahafall_client_reviews]' ); ?> 
                </div>
            </div>
        </div>
    </section>

    <!-- SIte CTA Section -->
    <?php echo do_shortcode( '[minnehahafall_CTA_section]' ); ?> 

</div>           
    

<?php
get_footer();