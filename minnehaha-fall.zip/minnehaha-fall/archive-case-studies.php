<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

get_header();

$description = get_the_archive_description();
?>
<div class="main-wrapper">
    <div class="container">
        <div class="about-content">
            <div class="content">
                <h1>Case Studies</h1>
            </div>
        </div>
    </div>
    <section class="casestudy">
        <div class="container">
            <div class="row">
            <?php if ( have_posts() ) : ?>
            
                <?php while ( have_posts() ) :  
                    $page_id = the_ID(); 
                    $banner_image = get_field( "banner_image", $page_id);
                    $page_title = get_field( "page_title", $page_id);
                    $page_description = get_field( "page_description", $page_id);                    
                    ?>
                    <div class="col-12 col-md-6 col-lg-6">
                        <div class="casestudy-item">
                            <img src="<?php echo $banner_image; ?>" alt="Image">
                            <h4><?php echo $page_title ?></h4>
                            <?php echo $page_description ?>
                            <div class="readmore">
                                <a href="fsfsdf<?php echo esc_url( get_permalink() ) ?>"> Read More <i class="material-icons card-action__icon">arrow_forward</i></a>
                            </div>
                        </div>
                    </div> 
                <?php endwhile; ?>

                <?php //twenty_twenty_one_the_posts_navigation(); ?>

            <?php else : ?>
                <?php get_template_part( 'template-parts/content/content-none' ); ?>
            <?php endif; ?>
            </div>
        </div>
    </section>
     <!-- Service Partners -->
     <?php echo do_shortcode( '[minnehahafall_service_partners]' ); ?> 

    <section class="section-wrapper contact-us">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="cform contact-form">
                        <h2>Get in Touch</h2>
                        <p>Call us at&nbsp;<a href="http://612-724-5454/">612-724-5454</a>&nbsp;to see what is possible with landscape design and construction, organic gardening, and indoor remodeling.</p>
                        <?php echo do_shortcode( '[contact-form-7 id="a33b622" title="Contact Form for all pages"]' ); ?> 
                    </div>
                </div>
                <div class="col-12 col-md-6">                
                <?php echo do_shortcode( '[minnehahafall_client_reviews]' ); ?> 
                </div>
            </div>
        </div>
    </section>

<!-- SIte CTA Section -->
<?php echo do_shortcode( '[minnehahafall_CTA_section]' ); ?> 

</div> 

<?php
get_footer();
