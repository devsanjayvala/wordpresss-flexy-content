<?php
/* Template Name: Home Page Template */ 
 
get_header(); ?>


<!-- Start HTML -->
<!--Call Us section start-->

<div class="main-wrapper">
    <?php 
    $page_id = get_the_ID();
    $banner_title = get_field( "banner_title", $page_id);
    $banner_description = get_field( "banner_description", $page_id);
    $banner_cta_link = get_field( "banner_cta_link", $page_id);
    ?>
    <section class="banner">
       <div class="banner">
            <div class="bslider">
                <?php
                $count = 0;
                if( have_rows('banner_item_list') ):
                while( have_rows('banner_item_list') ): the_row();
                    $name = get_sub_field('name');
                    $link = get_sub_field('link');
                    $image = get_sub_field('image');
                    if ($name !='' && $link != '' && $image != '') {
                        ?>
                        <div class="item">
                            <img src="<?php echo $image ?>" alt="Image">
                            <div class="inner-wrap">
                                <a href="<?php echo $link ?>" target="">
                                    <span class="title"><?php echo $name ?></span>
                                </a>
                            </div>
                        </div>
                        <?php
                    }
                    $count++;
                endwhile;
                endif;
                ?>
            </div>
            <?php
            if ($banner_title !='' && $banner_description !='' ) {
                ?>
                <div class="banner-text">
                    <span class="file-description">
                        <h4><?php echo $banner_title; ?></h4>
                        <a href="<?php echo $banner_cta_link; ?>">
                            <h3><?php echo $banner_description; ?></h3>
                        </a>
                    </span>
                </div>
            <?php } ?>
        </div>
    </section>


    <?php
    $about_title = get_field( "about_title", $page_id);
    $about_description = get_field( "about_description", $page_id);
    $about_image = get_field( "about_image", $page_id);
    $about_image_link = get_field( "about_image_link", $page_id);
    ?>
    <section class="section-wrapper award">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12 col-md-7 col-lg-8">
                    <div class="award-content">
                        <h3><?php echo $about_title ?></h3>
                        <p><?php echo $about_description ?></p>
                    </div>
                </div>
                <div class="col-12 col-md-5 col-lg-4">
                    <div class="award-image">
                        <a href="<?php echo $about_image_link; ?>"><img src="<?php echo $about_image; ?>" alt="Image"></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="section-wrapper service">
        <div class="container">
            <div class="row">
                <?php
                if( have_rows('services_list') ):
                while( have_rows('services_list') ): the_row();
                    $image = get_sub_field('image');
                    $name = get_sub_field('name');
                    $description = get_sub_field('description');
                    $link = get_sub_field('link');
                    
                    if ($name !='' && $link != '' && $image != '' && $description != '') {
                        ?> 
                        <div class="col-12 col-md-6 col-lg-3 p-0">
                            <div class="service-item">
                                <div class="service-image">
                                    <img src="<?php echo $image ?>" alt="Image">
                                </div>
                                <div class="service-content">
                                    <h3><?php echo $name ?></h3>
                                    <p><?php echo $description ?></p>
                                    <div class="readmore">
                                        <a href="<?php echo $link ?>">Read more</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    } 
                endwhile;
                endif;
                ?> 
            </div>
        </div>
    </section>
    
    <!-- Service Partners -->
    <?php echo do_shortcode( '[minnehahafall_service_partners]' ); ?> 

    <?php
    $form_title = get_field( "form_title", $page_id);
    $form_description = get_field( "form_description", $page_id);
    $form_shortcode = get_field( "form_shortcode", $page_id);
    ?>
    <section class="section-wrapper contact-us">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="cform contact-form">
                        <?php
                        if ($form_title !='' || $form_description !='' || $form_shortcode !='' ) {
                            echo '<h2>'.$form_title.'</h2>';
                            echo $form_description;
                            echo do_shortcode($form_shortcode);
                        }
                        ?> 
                    </div>
                </div>
                <div class="col-12 col-md-6">                
                <?php echo do_shortcode( '[minnehahafall_client_reviews]' ); ?> 
                </div>
            </div>
        </div>
    </section>
    
    <!-- SIte CTA Section -->
    <?php echo do_shortcode( '[minnehahafall_CTA_section]' ); ?>

</div>


<!--Call Us section end-->
<!-- End HTML -->


<?php
get_footer();
