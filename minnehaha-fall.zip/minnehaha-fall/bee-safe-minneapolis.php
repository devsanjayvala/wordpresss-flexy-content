<?php
/* Template Name: Bee Safe Minneapolis Page Template */ 

get_header(); ?>

<div class="main-wrapper">
    <section class="about-banner">
        <div class="banner-image">
            <img src="https://valainfotech.com/projects/minnehahafallslandscape/wp-content/uploads/2024/02/processsm.jpg" alt="Image">
        </div>
        <div class="banner-content">
            <h1>Bee Safe Minneapolis</h1>
            <h2>It’s your community. Have us come to speak about pollinators.</h2>
            <a href="">Request Speaker</a>
        </div>
    </section>
    <section class="section-wrapper bee-safe-page">
        
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-12 col-lg-12">
                <div class="content">                    
                    <h2>Learn How to Grow Pollinator Habitats From Experts</h2>
                    <h3>We, at Minnehaha Falls Landscaping, are proud to offer carefully designed landscapes crafted to suit your preferences while prioritizing sustainability.</h3>
                    <p>Bees and other pollinators are suffering from loss of habitat and widespread use of pesticides. In the face of such news, it’s easy to become overwhelmed, and feel paralyzed by a sense of powerlessness.</p>
                    <p>Increase habitat by planting or expanding a pollinator garden in your yard, and encouraging your neighbors to do the same. Sign the bee safe neighbor pledge and help show how together we can build continuous habitat for pollinators.</p>
                    <p>We want to talk to companies, schools and community groups teach how you can become Bee Safe. Encourage pollinator friendly practices where you work, where your children attend school, at your church and at local businesses you frequent. </p>                    
                </div>
            </div>
        </div>
    </div>
        <div class="container">
            <div class="row"> 
                <div class="col-12 col-md-6">
                    <div class="cform contact-form">
                        <h2>Have us come and speak to your group. Fill out the form below</h2>
                        <?php echo do_shortcode( '[contact-form-7 id="a33b622" title="Contact Form for all pages"]' ); ?> 
                    </div>
                </div>
                <div class="col-12 col-md-6">
                    <div class="contact-image">
                        <img src="https://minnehahafallslandscape.com/cms-files/size-992x992/croppedruss-henry-head-shot.jpg" alt="Image">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section-wrapper feature">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-4 col-lg-4">
                    <div class="feature-item">
                        <div class="feature-image">
                            <a href="/bee-safe-minneapolis/" target="_blank">
                                <img src="https://valainfotech.com/projects/minnehahafallslandscape/wp-content/themes/minnehaha-fall/assets/images/bee-safe.png" alt="Image">
                            </a>
                        </div>
                        <div class="feature-content">
                            <p>As the education and advocacy branch, we work with community partners to create safe places for our pollinators, one garden, yard, business, school, church, conversation at a time. We know that together, we can build the buzz!</p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-4">
                    <div class="feature-item">
                        <div class="feature-image">
                            <a href="https://minnehaharemodeling.com/" target="_blank">
                                <img src="https://valainfotech.com/projects/minnehahafallslandscape/wp-content/themes/minnehaha-fall/assets/images/remodeling.png" alt="Image">
                            </a>
                        </div>
                        <div class="feature-content">
                            <p>As the construction branch of Minnehaha Falls Landscaping, we build outdoor decks, steps, railings, pergolas, fences, and planters. When it gets colder, we step inside to remodel living spaces with creativity and craftsmanship, including cabinetry.</p>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-lg-4">
                    <div class="feature-item">
                        <div class="feature-image">
                            <a href="https://givingtreegardens.com/" target="_blank">
                                <img src="https://valainfotech.com/projects/minnehahafallslandscape/wp-content/themes/minnehaha-fall/assets/images/giving.png" alt="Image">
                            </a>
                        </div>
                        <div class="feature-content">
                            <p>As the gardening branch, we work within your landscape to grow plants, flowers, shrubs and woodland gardens that are beautiful, restorative, and safe for birds, people, pets, and pollinators. We also install bee-friendly lawns and do spring and fall clean-up.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section-wrapper call-us">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6 col-lg-6">
                    <div class="call-inner">
                        <h3>Lets talk!</h3>
                        <h4>Call us at <a href="tel:6127245454">612-724-5454</a></h4>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-6">
                    <div class="call-btn">
                        <a href="/contact">Get a Quote</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php
get_footer();