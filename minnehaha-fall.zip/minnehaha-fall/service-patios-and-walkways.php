<?php
/* Template Name: Service Patios-and-walkways Page Template */ 
 
get_header();
?>

<link href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css" rel="stylesheet" >

<?php
// Get the directory URI of the child theme
$child_theme_uri = get_stylesheet_directory_uri();

$page_id = get_the_ID();
$banner_title = get_field( "banner_title", $page_id);
$banner_link = get_field( "banner_link", $page_id);

$tage_line = get_field( "tage_line", $page_id);
$page_description = get_field( "page_description", $page_id);
$gallery_title = get_field( "gallery_title", $page_id);
$gallery_sub_title = get_field( "gallery_sub_title", $page_id);
$gallery_description = get_field( "gallery_description", $page_id);
?>

<div class="main-wrapper"> 
    <section class="about-banner slider-with-text">
        <div class="banner-slider">
            <div class="banner-slide">
                <?php
                if( have_rows('banner_list') ):
                    while( have_rows('banner_list') ): the_row();
                        $image = get_sub_field('image');                                      
                        if ($image != '') {
                            ?>
                            <div class="slide">
                                <img src="<?php echo $image; ?>" alt="Image">
                            </div> 
                            <?php
                        } 
                    endwhile;
                endif;
                ?> 
            </div>
        </div> 
        <div class="banner-text">
            <div class="banner-text-inner">
                <h2><?php echo $banner_title; ?></h2>
                <a href="<?php echo $banner_link; ?>" tabindex="0"><p>Request a Quote</p></a>
            </div>
        </div>
    </section>
    <section class="section-wrapper about-content patios">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="content">
                        <p><strong><?php echo $tage_line; ?></p> 
                        <?php echo $page_description; ?>
                        <?php
                        $item = 0;
                        if( have_rows('item_list') ):
                            while( have_rows('item_list') ): the_row();
                                $title = get_sub_field('title');
                                $description = get_sub_field('description'); 
                                $image = get_sub_field('image');
                                if ($title != '') {
                                    if ( $item %2 == 0 ) {
                                        ?>
                                        <div class="image-with-content">
                                            <div class="image-content">
                                                <h2><?php echo $title; ?></h2>
                                                <?php echo $description; ?>
                                            </div>
                                            <div class="image-image">
                                                <img src="<?php echo $image; ?>" alt="image">
                                            </div>
                                        </div>
                                        <?php 
                                    } else {
                                        ?>
                                        <div class="image-with-content last">
                                            <div class="image-image">
                                                <img src="<?php echo $image; ?>" alt="image">
                                            </div>
                                            <div class="image-content">
                                                <h2><?php echo $title; ?></h2>
                                                <?php echo $description; ?>
                                            </div>
                                        </div> 
                                        <?php
                                    }
                                }
                                $item++;
                            endwhile;
                        endif;
                        ?>  

                        <div class="image-gallery">
                            <div class="container">
                                <h3><?php echo $gallery_title; ?></h3>
                                <p><strong><?php echo $gallery_sub_title; ?></strong></p>
                                <p><?php echo $gallery_description; ?></p>
                                <div class="gallery">
                                    <div class="row">
                                        <div class="gallery-tabs">
                                            <a class="selected" data-cat="all">All</a>                                        
                                            <a data-cat="patios">Patios</a>
                                            <a data-cat="walkway">Walkway</a>
                                            <a data-cat="retaining-walls">Retaining Walls</a>
                                            <a data-cat="seat-walls">Seat Walls</a>
                                            <a data-cat="pool-surrounds">Pool Surrounds</a>
                                            <a data-cat="stairs">Stairs</a>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <?php
                                        $item = 0;
                                        if( have_rows('gallery_images') ):
                                            while( have_rows('gallery_images') ): the_row();
                                                $category = get_sub_field('category'); 
                                                $image = get_sub_field('image');
                                                if ($category != '' && $image !='') {
                                                    $cate =  strtolower(str_replace(" ","-",$category));
                                                     ?>
                                                     <div class="gallery-box col-12 col-sm-6 col-md-6 col-lg-3" data-width="1000" data-height="800" data-catagory="<?php echo $cate; ?>">
                                                        <a href="<?php echo $image; ?>" data-bs-toggle="lightbox" data-bs-gallery="gallery" data-lightbox="<?php echo $cate; ?>" data-title="Backyard Patio Designs.jpg">
                                                            <img src="<?php echo $image; ?>" alt="gallery">
                                                        </a>
                                                    </div>
                                                    <?php 
                                                }
                                                $item++;
                                            endwhile;
                                        endif;
                                        ?> 
                                    </div>
                                </div>
                            </div>
                        </div>    
                        <script>
                        $('.gallery-tabs a').each(function(){
                            
                            $(this).click(function(){
                                
                                if($(this).hasClass('selected')){
                                    cat_id = 'all';
                                } else {
                                    cat_id = $(this).data('cat');
                                }
                                
                                if(cat_id == 'all'){
                                    images = $('.gallery .gallery-box').show();
                                } else {
                                images = $('.gallery .gallery-box');
                                images.filter('[data-catagory='+cat_id+']').show();
                                images.filter(':not([data-catagory='+cat_id+'])').hide();
                                }

                                $('.gallery-tabs a').filter('[data-cat='+cat_id+']').addClass('selected');
                                $('.gallery-tabs a').filter(':not([data-cat='+cat_id+'])').removeClass('selected');
                                
                            });
                        });
                        </script>              
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- Service Partners -->
    <?php echo do_shortcode( '[minnehahafall_service_partners]' ); ?> 

    <?php
    $form_title = get_field( "form_title", $page_id);
    $form_description = get_field( "form_description", $page_id);
    $form_shortcode = get_field( "form_shortcode", $page_id);
    ?>
    <section class="section-wrapper contact-us">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6">
                    <div class="cform contact-form">
                        <?php
                        if ($form_title !='' || $form_description !='' || $form_shortcode !='' ) {
                            echo '<h2>'.$form_title.'</h2>';
                            echo '<p>Call us at <a href="tel:612-724-5454">612-724-5454</a> to see what is possible with landscape design and construction, organic gardening, and indoor remodeling.</p>';
                            echo do_shortcode($form_shortcode);
                        }
                        ?> 
                    </div>
                </div>
                <div class="col-12 col-md-6">                
                <?php echo do_shortcode( '[minnehahafall_client_reviews]' ); ?> 
                </div>
            </div>
        </div>
    </section>

    <!-- SIte CTA Section -->
    <?php echo do_shortcode( '[minnehahafall_CTA_section]' ); ?>

</div> 

<?php
get_footer();
?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.min.js"></script>
<script>
$(document).on("click", '[data-bs-toggle="lightbox"]', function(event) {
  event.preventDefault();
  $(this).ekkoLightbox();
});
</script>